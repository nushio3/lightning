/*
 *  aux.c
 *  LIME, The versatile 3D line modeling environment 
 *
 *  Created by Christian Brinch on 16/11/06.
 *  Copyright 2006-2013, Christian Brinch, 
 *  <brinch@nbi.dk>
 *  Niels Bohr institutet
 *  University of Copenhagen
 *	All rights reserved.
 *
 */

#include "lime.h"
#include <gsl/gsl_sort.h>
#include <gsl/gsl_statistics.h>


void 
parseInput(inputPars *par, image **img, molData **m){
  FILE *fp;
  int i,id;
  double BB[3];

/* Set default values */
  par->dust  	    = NULL;
  par->inputfile    = NULL;
  par->outputfile   = NULL;
  par->binoutputfile= NULL;
  par->gridfile     = NULL;
  par->pregrid	    = NULL;
  par->restart      = NULL;

  par->tcmb = 2.728;
  par->lte_only=0;
  par->sampling=0;
  par->blend=0;
  par->polarization=0;
  par->pIntensity=0;
  par->sinkPoints=0;
  par->threads=0;
  
  /* Allocate space for output fits images */
  (*img)=malloc(sizeof(image)*100);
  par->moldatfile=malloc(sizeof(char *) * 100);
  for(id=0;id<100;id++){
    (*img)[id].filename=NULL;
    par->moldatfile[id]=NULL;
  }
  input(par, *img);
  id=0;
  while((*img)[++id].filename!=NULL);
  par->nImages=id;
  if(par->nImages==0) {
    if(!silent) bail_out("Error: no images defined");
    exit(1);
  }
  
  free(*img);
  *img=malloc(sizeof(image)*par->nImages);
  
  
  
  id=-1;
  while(par->moldatfile[++id]!=NULL);
  par->nSpecies=id;
  
  free(par->moldatfile);
  par->moldatfile=malloc(sizeof(char *)*par->nSpecies);
  
  
  /* Set defaults and read inputPars and img[] */
  for(i=0;i<par->nImages;i++) {
    (*img)[i].source_vel=0.0;
    (*img)[i].phi=0.0;
    (*img)[i].nchan=0;
    (*img)[i].velres=-1.;
    (*img)[i].trans=-1;
    (*img)[i].freq=-1.;
    (*img)[i].bandwidth=-1.;
  }
  input(par,*img);
  
  if(par->threads == 0){
    par->threads = nthreads;
  }
  
  par->ncell=par->pIntensity+par->sinkPoints;
  
  /* Check if files exists */
  for(id=0;id<par->nSpecies;id++){
    if((fp=fopen(par->moldatfile[id], "r"))==NULL) {
      openSocket(par, id);
    }
  }
  if(par->dust != NULL){
    if((fp=fopen(par->dust, "r"))==NULL){
      if(!silent) bail_out("Error opening dust opacity data file!");
      exit(1);
    }
  }
  
  
  
  
  
  /* Allocate pixel space and parse image information */
  for(i=0;i<par->nImages;i++){
    if((*img)[i].nchan == 0 && (*img)[i].velres<0 ){
      /* Assume continuum image */
      
      /* Check for polarization */
      BB[0]=0.;
      magfield(par->minScale,par->minScale,par->minScale,BB);
      if(fabs(BB[0]) > 0.) par->polarization=1;
      
      if(par->polarization) (*img)[i].nchan=3;
      else (*img)[i].nchan=1;
      if((*img)[i].trans>-1 || (*img)[i].bandwidth>-1. || (*img)[i].freq==0 || par->dust==NULL){
        if(!silent) bail_out("Error: Image keywords are ambiguous");
        exit(1);
      }
      (*img)[i].doline=0;		  
    } else if (((*img)[i].nchan>0 || (*img)[i].velres > 0)){
      /* Assume line image */	
      par->polarization=0;
      if(par->moldatfile==NULL){
        if(!silent) bail_out("Error: No data file is specified for line image.");
        exit(1);		
      }
      if(((*img)[i].trans>-1 && (*img)[i].freq>-1) || ((*img)[i].trans<0 && (*img)[i].freq<0)){
        if(!silent) bail_out("Error: Specify either frequency or transition ");
        exit(1);						
      }	
      if(((*img)[i].nchan==0 && (*img)[i].bandwidth<0) || ((*img)[i].bandwidth<0 && (*img)[i].velres<0)){
        if(!silent) bail_out("Error: Image keywords are not set properly");
        exit(1);
      }
      (*img)[i].doline=1;
    }
    (*img)[i].imgres=(*img)[i].imgres/206264.806;
    (*img)[i].pixel = malloc(sizeof(spec)*(*img)[i].pxls*(*img)[i].pxls);
    for(id=0;id<((*img)[i].pxls*(*img)[i].pxls);id++){
      (*img)[i].pixel[id].intense = malloc(sizeof(double)*(*img)[i].nchan);
      (*img)[i].pixel[id].tau = malloc(sizeof(double)*(*img)[i].nchan);
    }
  }
  /* Allocate moldata array */
  if(par->nSpecies > 1) (*m)=malloc(sizeof(molData)*par->nSpecies);
  else (*m)=malloc(sizeof(molData)*1);
  
}


float 
invSqrt(float x){
  /* The magic Quake(TM) fast inverse square root algorithm   */
  /* Can _only_ be used on 32-bit machine architectures       */
  float xhalf = 0.5f*x;
  int i = *(int*)&x;
  i = 0x5f3759df - (i>>1);
  x = *(float*)&i;
  x = x*(1.5f - xhalf*x*x);
  return x;
}

void 
continuumSetup(int im, image *img, molData *m, inputPars *par, struct grid *g){
  int id; 
  img[im].trans=0;
  m[0].nline=1;
  m[0].freq= malloc(sizeof(double));
  m[0].freq[0]=img[im].freq;
  for(id=0;id<par->ncell;id++) {
    g[id].mol=malloc(sizeof(struct populations)*1);	
    g[id].mol[0].dust = malloc(sizeof(double)*m[0].nline);
    g[id].mol[0].knu  = malloc(sizeof(double)*m[0].nline);
  } 
  if(par->outputfile) popsout(par,g,m);
  kappa(m,g,par,0);
}

void
lineCount(int n,molData *m,int **counta,int **countb,int *nlinetot){
  int ispec,iline,count;	
  
  *nlinetot=0;
  for(ispec=0;ispec<n;ispec++) *nlinetot+=m[ispec].nline;
  if(*nlinetot > 0){
    *counta=malloc(sizeof(int)* *nlinetot);
    *countb=malloc(sizeof(int)* *nlinetot);
  } else {
    if(!silent) bail_out("Error: Line count finds no lines");
    exit(0);
  }
  count=0;
  for(ispec=0;ispec<n;ispec++) {
    for(iline=0;iline<m[ispec].nline;iline++){
      (*counta)[count]=ispec;
      (*countb)[count++]=iline;			
    }
  }
}

void
lineBlend(molData *m, inputPars *par, blend **matrix){
  int iline, jline, nlinetot=0,c;
  int *counta,*countb;
  
  lineCount(par->nSpecies, m, &counta, &countb, &nlinetot);	
  
  c=0;
  for(iline=0;iline<nlinetot;iline++){
    for(jline=0;jline<nlinetot;jline++){  
      if(fabs((m[counta[jline]].freq[countb[jline]]-m[counta[iline]].freq[countb[iline]])/m[counta[iline]].freq[countb[iline]]*CLIGHT) < blendmask
         && iline !=jline) c++;
    }
  }
  if(c>0){
    if(par->blend){
      if(!silent) warning("There are blended lines (Line blending is switched on)");
    } else {
      if(!silent) warning("There are blended lines (Line blending is switched off)");
    }
    
    (*matrix)=malloc(sizeof(blend)*c);
    
    c=0;
    for(iline=0;iline<nlinetot;iline++){
      for(jline=0;jline<nlinetot;jline++){  
        if(fabs((m[counta[jline]].freq[countb[jline]]-m[counta[iline]].freq[countb[iline]])/m[counta[iline]].freq[countb[iline]]*CLIGHT) < blendmask
           && iline != jline){
          (*matrix)[c].line1=iline;
          (*matrix)[c].line2=jline;
          (*matrix)[c++].deltav=-(m[counta[jline]].freq[countb[jline]]-m[counta[iline]].freq[countb[iline]])/m[counta[iline]].freq[countb[iline]]*CLIGHT;				
        }			
      }						
    }		
  }
  free(counta);
  free(countb);
  
}

void
levelPops(molData *m, inputPars *par, struct grid *g, int *popsdone){
  int id,conv=0,iter,ilev,prog=0,ispec,c=0,n,count;
  double percent=0.,*median,result1=0,result2=0,snr;
  blend *matrix;
  struct statistics { double *pop, *ave, *sigma; } *stat;
  
  stat=malloc(sizeof(struct statistics)*par->pIntensity);
  
  for(id=0;id<par->ncell;id++) {
    g[id].mol=malloc(sizeof(struct populations)*par->nSpecies);
  }
  
  /* Random number generator */
  gsl_rng *ran = gsl_rng_alloc(gsl_rng_ranlxs2);
  gsl_rng_set(ran,time(0));
  
  /* Read in all molecular data */
  for(id=0;id<par->nSpecies;id++) molinit(m,par,g,id);
  
  /* Check for blended lines */
  lineBlend(m,par,&matrix);
  
  if(par->lte_only) LTE(par,g,m);
  
  for(id=0;id<par->pIntensity;id++){
    stat[id].pop=malloc(sizeof(double)*m[0].nlev*5);
    stat[id].ave=malloc(sizeof(double)*m[0].nlev);
    stat[id].sigma=malloc(sizeof(double)*m[0].nlev);
    for(ilev=0;ilev<m[0].nlev;ilev++) {
      for(iter=0;iter<5;iter++) stat[id].pop[ilev+m[0].nlev*iter]=g[id].mol[0].pops[ilev];
    }
  }
  
  if(par->outputfile) popsout(par,g,m);
  
  
  /* Initialize convergence flag */
  for(id=0;id<par->ncell;id++){
    g[id].conv=0;
  }
  
  if(par->lte_only==0){
    do{
      if(!silent) progressbar2(prog++, 0, result1, result2);
      
      for(id=0;id<par->ncell && !g[id].sink;id++){
        for(ilev=0;ilev<m[0].nlev;ilev++) {
          for(iter=0;iter<4;iter++) stat[id].pop[ilev+m[0].nlev*iter]=stat[id].pop[ilev+m[0].nlev*(iter+1)];
          stat[id].pop[ilev+m[0].nlev*4]=g[id].mol[0].pops[ilev];
        }
      }
      
      
      
      count=0;
      omp_set_dynamic(0);
#pragma omp parallel private(id,ispec) num_threads(par->threads)
      {
        double *phot,*vfac,*ds;
        gsl_rng *localran = gsl_rng_alloc(gsl_rng_ranlxs2);
        gsl_rng_set(localran,(int) gsl_rng_uniform(ran)*1e6);
        
#pragma omp for
        for(id=0;id<par->pIntensity;id++){
#pragma omp critical
          {
            ++count;
          }
          if (omp_get_thread_num() == 0){
            if(!silent) progressbar((double)count/par->pIntensity,10);
          }
          phot=malloc(sizeof(double)*m[0].nline*max_phot);
          vfac=malloc(sizeof(double)*g[id].nphot);
          ds=malloc(sizeof(double)*g[id].nphot);
          if(g[id].dens[0] > 0 && g[id].t[0] > 0){
            photon(id,g,m,0,localran,par,matrix,phot,vfac,ds);
            for(ispec=0;ispec<par->nSpecies;ispec++) stateq(id,g,m,ispec,par,phot,vfac,ds);
          }
          free(phot);
          free(ds);
          free(vfac);

          if (omp_get_thread_num() == 0){
            if(!silent) warning("");
          }
        }
        gsl_rng_free(localran);
      }
      
      
      
      for(id=0;id<par->ncell && !g[id].sink;id++){
        snr=0;
        n=0;
        for(ilev=0;ilev<m[0].nlev;ilev++) {
          stat[id].ave[ilev]=0;
          for(iter=0;iter<5;iter++) stat[id].ave[ilev]+=stat[id].pop[ilev+m[0].nlev*iter];
          stat[id].ave[ilev]=stat[id].ave[ilev]/5.;
          stat[id].sigma[ilev]=0;
          for(iter=0;iter<5;iter++) stat[id].sigma[ilev]+=pow(stat[id].pop[ilev+m[0].nlev*iter]-stat[id].ave[ilev],2);
          stat[id].sigma[ilev]=sqrt(stat[id].sigma[ilev])/5.;
          if(g[id].mol[0].pops[ilev] > 1e-12) c++;
          
          if(g[id].mol[0].pops[ilev] > 1e-12 && stat[id].sigma[ilev] > 0.){
            snr+=g[id].mol[0].pops[ilev]/stat[id].sigma[ilev];
            n++;
          }
        }
        if(n>0) snr=snr/n;
        else if(n==0) snr=1e6;
        if(snr > 3.) g[id].conv=2;
        if(snr <= 3 && g[id].conv==2) g[id].conv=1;
      }
      
      
      median=malloc(sizeof(double)*gsl_max(c,1));
      c=0;
      for(id=0;id<par->pIntensity;id++){
        for(ilev=0;ilev<m[0].nlev;ilev++){
          if(g[id].mol[0].pops[ilev] > 1e-12) median[c++]=g[id].mol[0].pops[ilev]/stat[id].sigma[ilev];
        }
      }
      
      gsl_sort(median, 1, c);
      if(conv>1){
        result1=median[0];
        result2 =gsl_stats_median_from_sorted_data(median, 1, c);
      }
      free(median);
      
      if(!silent) progressbar2(prog, percent, result1, result2);
      if(par->outputfile) popsout(par,g,m);
    } while(conv++<NITERATIONS);
    if(par->binoutputfile) binpopsout(par,g,m);
  }
  
  //  gsl_rng_free(ran);
  //  free(matrix);
  free(stat);
  *popsdone=1;
}



